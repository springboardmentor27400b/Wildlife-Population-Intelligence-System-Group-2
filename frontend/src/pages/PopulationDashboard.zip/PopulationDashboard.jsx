import { useEffect, useState } from "react";
import api from "../api";
import {
    PieChart,
    Pie,
    Cell,
    Tooltip,
    ResponsiveContainer,
    BarChart,
    Bar,
    LineChart,
    XAxis,
    Line,
    YAxis,
    CartesianGrid,
    Legend
} from "recharts";

function PopulationDashboard() {

    const [loading, setLoading] = useState(false);
    const [metrics, setMetrics] = useState(null);
    const [history, setHistory] = useState([]);
    const [alerts, setAlerts] = useState([]);
    const [lastUpdated, setLastUpdated] = useState("");

    const loadDashboard = async () => {

        setLoading(true);
    
        setLastUpdated(new Date().toLocaleString());
        try {
            
            const res = await api.get("/dashboard/metrics",{
            });

            setMetrics(res.data);

        } catch (err) {

            console.log(err);

        } finally {

            setLoading(false);

        }

    };
    const loadHistory = async () => {

        try {

            const res = await api.get("/dashboard/history");

            setHistory(res.data);

        } catch (err) {

            console.log(err);

        }

    };
    const loadAlerts = async () => {

        try {

            const res = await api.post(

                "/alerts/generate",

                metrics.population_metrics

            );

            setAlerts(res.data);

        }

        catch(err){

            console.log(err);

        }

    };
    useEffect(() => {

        loadDashboard();
        loadHistory();

    }, []);
    useEffect(() => {

    loadDashboard();

    const interval = setInterval(() => {

        loadDashboard();

    }, 30000);

    return () => clearInterval(interval);

    }, []);
    useEffect(() => {

    setHistory([

        {
            month: "Jan",
            population: 18
        },

        {
            month: "Feb",
            population: 22
        },

        {
            month: "Mar",
            population: 19
        },

        {
            month: "Apr",
            population: 25
        },

        {
            month: "May",
            population: 28
        },

        {
            month: "Jun",
            population: metrics?.population_metrics.population_size || 30
        }

    ]);

    }, [metrics]);
    useEffect(() => {

    if(metrics){

        loadAlerts();

    }

    },[metrics]);

    if (loading)
        return <h2 className="text-center mt-10">Loading...</h2>;

    if (!metrics)
        return <h2>No Data</h2>;

    const COLORS = [

        "#10B981",

        "#3B82F6",

        "#F59E0B",

        "#EF4444",

        "#8B5CF6",

        "#06B6D4"

    ];
    const generateReport = async () => {
    try {

        const reportData = {
            population_size: metrics.population_metrics.population_size,
            density: metrics.population_metrics.density,
            growth_rate: metrics.population_metrics.growth_rate,
            trend: metrics.population_metrics.trend,
            migration_status: metrics.population_metrics.migration_status,
            dominant_species: metrics.population_metrics.dominant_species,
            species_richness: metrics.population_metrics.species_richness,
        };

        // Generate the report
        await api.post("/report/generate", reportData);

        // Download the generated PDF
        const response = await api.get("/report/download", {
            responseType: "blob",
        });

        const url = window.URL.createObjectURL(
            new Blob([response.data])
        );

        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", "population_report.pdf");

        document.body.appendChild(link);
        link.click();

        link.remove();
        window.URL.revokeObjectURL(url);

    } catch (err) {

        console.error(err);

    }
    };
    
    return (

        <div className="p-6">

            <h1 className="text-3xl font-bold mb-6">
                Population Dashboard
            </h1>
          

            <div className="mb-6">

                <button

                onClick={loadDashboard}

                className="bg-green-600
                text-white
                px-4
                py-2
                rounded
                mb-5"

                >

                Refresh Dashboard

                </button>

            </div>
            <div className="bg-blue-50 rounded-xl shadow p-6 mb-6">

            <h2 className="text-2xl font-bold">

            Wildlife Summary

            </h2>

            <p>

            Total Population :
            {metrics.population_metrics.population_size}

            </p>

            <p>

            Dominant Species :
            {metrics.population_metrics.dominant_species}

            </p>

            <p>

            Population Trend :
            {metrics.population_metrics.trend}

            </p>

            </div>

            <div className="grid grid-cols-4 gap-4 mt-6">
                ...
            </div>

            <div className="grid grid-cols-4 gap-4 mt-6">

            <div className="bg-white shadow-lg rounded-xl p-5">
                <h3 className="text-gray-500">Population Size</h3>
                <p className="text-3xl font-bold">
                    {metrics.population_metrics.population_size}
                </p>
            </div>

            <div className="bg-white shadow-lg rounded-xl p-5">
                <h3 className="text-gray-500">Density</h3>
                <p className="text-3xl font-bold">
                    {metrics.population_metrics.density} / km²
                </p>
            </div>

            <div className="bg-white shadow-lg rounded-xl p-5">
                <h3 className="text-gray-500">Growth Rate</h3>
                <p className="text-3xl font-bold text-green-600">
                    {metrics.population_metrics.growth_rate}%
                </p>
            </div>

            <div className="bg-white shadow-lg rounded-xl p-5">
                <h3 className="text-gray-500">Trend</h3>
                <p className="text-2xl font-bold">
                    {metrics.population_metrics.trend}
                </p>
            </div>

            <div className="bg-white shadow-lg rounded-xl p-5">
                <h3 className="text-gray-500">Migration</h3>
                <p className="text-xl font-bold">
                    {metrics.population_metrics.migration_status}
                </p>
            </div>

            <div className="bg-white shadow-lg rounded-xl p-5">
                <h3 className="text-gray-500">Migration Pattern</h3>
                <p className="text-lg">
                    {metrics.population_metrics.migration_pattern}
                </p>
            </div>

            <div className="bg-white shadow-lg rounded-xl p-5">
                <h3 className="text-gray-500">Species Richness</h3>
                <p className="text-3xl font-bold">
                    {metrics.population_metrics.species_richness}
                </p>
            </div>

            <div className="bg-white shadow-lg rounded-xl p-5">
                <h3 className="text-gray-500">Dominant Species</h3>
                <p className="text-2xl font-bold text-blue-700">
                    {metrics.population_metrics.dominant_species}
                </p>
            </div>

        </div>
        <div className="mt-10 bg-white rounded-xl shadow-lg p-6">

            <h2 className="text-2xl font-bold mb-5">

                Species Distribution

            </h2>

            <table className="table-auto w-full border">

                <thead className="bg-green-700 text-white">

                    <tr>

                        <th className="p-3">Species</th>

                        <th className="p-3">Count</th>

                    </tr>

                </thead>

                <tbody>

                    {metrics.species_distribution.map((item,index)=>(

                        <tr
                            key={index}
                            className="text-center border-b"
                        >

                            <td className="p-3">

                                {item.species}

                            </td>

                            <td className="p-3">

                                {item.count}

                            </td>

                        </tr>

                    ))}

                </tbody>

            </table>

        </div>
        <div className="bg-white rounded-xl shadow-lg p-6 mt-8">

            <h2 className="text-2xl font-bold mb-5">

                Species Count

            </h2>

            <ResponsiveContainer
                width="100%"
                height={350}
            >

                <BarChart
                    data={metrics.species_distribution}
                >

                    <CartesianGrid strokeDasharray="3 3"/>

                    <XAxis dataKey="species"/>

                    <YAxis/>

                    <Tooltip/>

                    <Legend/>

                    <Bar
                        dataKey="count"
                        fill="#16A34A"
                    />

                </BarChart>

            </ResponsiveContainer>

        </div>
        <div className="bg-white rounded-xl shadow-lg p-6 mt-8">

            <h2 className="text-2xl font-bold mb-5">

                Species Distribution

            </h2>

            <ResponsiveContainer
                width="100%"
                height={350}
            >

                <PieChart>

                    <Pie

                        data={metrics.species_distribution}

                        dataKey="count"

                        nameKey="species"

                        outerRadius={120}

                        label

                    >

                        {

                            metrics.species_distribution.map(

                                (entry,index)=>(

                                    <Cell

                                        key={index}

                                        fill={

                                            COLORS[index % COLORS.length]

                                        }

                                    />

                                )

                            )

                        }

                    </Pie>

                    <Tooltip/>

                </PieChart>

            </ResponsiveContainer>

        </div>
        <div className="bg-white rounded-xl shadow-lg p-6 mt-8">

            <h2 className="text-2xl font-bold mb-5">

            Population Growth Trend

            </h2>

            <ResponsiveContainer

            width="100%"

            height={350}

            >

            <LineChart

            data={history}

            >

            <CartesianGrid strokeDasharray="3 3"/>

            <XAxis dataKey="month"/>

            <YAxis/>

            <Tooltip/>

            <Legend/>

            <Line

            type="monotone"

            dataKey="population"

            stroke="#16A34A"

            strokeWidth={3}

            />

            </LineChart>

            </ResponsiveContainer>

        </div>
        <div className="mt-8">

            <h2 className="text-2xl font-bold mb-4">

            AI Conservation Alerts

            </h2>

            {

            alerts.map((alert,index)=>(

            <div

            key={index}

            className="bg-red-50 border-l-4 border-red-600 p-4 mb-3 rounded"

            >

            <h3 className="font-bold">

            {alert.type}

            </h3>

            <p>

            {alert.message}

            </p>

            </div>

            ))

            }

        </div>
        <button

            onClick={generateReport}

            className="bg-blue-600 text-white px-5 py-2 rounded"

            >

            Download Report

        </button>
        </div>

    );

}

export default PopulationDashboard;